using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TeatroForm
{
    public partial class InicioTeatro : Form
    {
        private Button[,] asientos = new Button[4, 5];
        private string connectionString = "Server=USUARIO-KM2D7KC;Database=Teatro;Trusted_Connection=True;";

        public InicioTeatro()
        {
            InitializeComponent();
            CrearInterfazTeatro();
            CrearBotonesMenu();
            GuardarAsientosEnBD();
        }

        private void InicioTeatro_Load(object sender, EventArgs e)
        {
            CargarReservasDesdeBD();
        }

        private void CrearInterfazTeatro()
        {
            this.BackColor = Color.White;

            Label pantalla = new Label
            {
                Text = "Pantalla",
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Arial", 15, FontStyle.Bold),
                Size = new Size(350, 40),
                Location = new Point(50, 20),
                BackColor = Color.White
            };
            this.Controls.Add(pantalla);

            int posX = 50;
            int posY = 100;
            int tamanoBoton = 60;

            for (int fila = 0; fila < 4; fila++)
            {
                for (int columna = 0; columna < 5; columna++)
                {
                    asientos[fila, columna] = new Button
                    {
                        Size = new Size(tamanoBoton, tamanoBoton),
                        Location = new Point(
                            posX + (columna * (tamanoBoton + 10)),
                            posY + (fila * (tamanoBoton + 10))
                        ),
                        BackColor = Color.Green,
                        Tag = "Disponible"
                    };

                    asientos[fila, columna].MouseEnter += (s, e) => MostrarPosicionAsiento((Button)s);
                    asientos[fila, columna].Click += SeleccionarAsiento;
                    this.Controls.Add(asientos[fila, columna]);
                }
            }
        }

        private void MostrarPosicionAsiento(Button button)
        {
            int filaPos = -1;
            int columnaPos = -1;

            for (int i = 0; i < asientos.GetLength(0); i++)
            {
                for (int j = 0; j < asientos.GetLength(1); j++)
                {
                    if (asientos[i, j] == button)
                    {
                        filaPos = i + 1; // Convertir a �ndice de fila 1-based
                        columnaPos = j + 1; // Convertir a �ndice de columna 1-based
                        break;
                    }
                }
            }

            if (filaPos > 0 && columnaPos > 0)
            {
                ToolTip tt = new ToolTip();
                tt.SetToolTip(button, $"Fila {filaPos}, Columna {columnaPos}");
            }
        }

        private void CrearBotonesMenu()
        {
            string[] menuItems =
            {
                "Ver Asientos Disponibles",
                "Reservar un Asiento",
                "Cancelar Reserva",
                "Ver Todas las Reservas"
            };

            for (int i = 0; i < menuItems.Length; i++)
            {
                Button btn = new Button
                {
                    Text = menuItems[i],
                    Size = new Size(200, 40),
                    Location = new Point(400, 100 + (i * 50))
                };

                if (i == 0) btn.Click += (s, e) => MostrarAsientosDisponibles();
                if (i == 1) btn.Click += (s, e) => ReservarAsiento();
                if (i == 2) btn.Click += (s, e) => CancelarReserva();
                if (i == 3) btn.Click += (s, e) => MostrarReservas();

                this.Controls.Add(btn);
            }
        }

        private void SeleccionarAsiento(object sender, EventArgs e)
        {
            if (sender is Button asientoSeleccionado)
            {
                string estado = asientoSeleccionado.Tag?.ToString();
                switch (estado)
                {
                    case "Disponible":
                        MessageBox.Show("Seleccione el bot�n de 'Reservar un Asiento' para proceder con la reserva.");
                        break;
                    case "Ocupado":
                        MessageBox.Show("Este asiento ya est� reservado.");
                        break;
                }
            }
        }

        public void MostrarAsientosDisponibles()
        {
            string disponibles = "Asientos disponibles:\n";
            for (int fila = 0; fila < 4; fila++)
            {
                for (int columna = 0; columna < 5; columna++)
                {
                    if (asientos[fila, columna].Tag?.ToString() == "Disponible")
                    {
                        disponibles += $"Fila {fila + 1}, Columna {columna + 1}\n";
                    }
                }
            }
            MessageBox.Show(disponibles, "Asientos Disponibles");
        }

        public void ReservarAsiento()
        {
            string input = Microsoft.VisualBasic.Interaction.InputBox("Ingrese la fila y columna (formato: fila,columna):", "Reservar Asiento", "1,1");
            var coords = input.Split(',');

            if (coords.Length == 2 && int.TryParse(coords[0], out int fila) && int.TryParse(coords[1], out int columna))
            {
                fila -= 1; // Ajustar para el �ndice basado en 0
                columna -= 1;

                if (fila >= 0 && fila < 4 && columna >= 0 && columna < 5)
                {
                    if (asientos[fila, columna].Tag.ToString() == "Disponible")
                    {
                        string nombreCliente = Microsoft.VisualBasic.Interaction.InputBox("Ingrese su nombre:", "Reservar Asiento", "Nombre");

                        if (!string.IsNullOrEmpty(nombreCliente))
                        {
                            try
                            {
                                using (SqlConnection connection = new SqlConnection(connectionString))
                                {
                                    connection.Open();

                                    // Obtener el siguiente IdReserva
                                    int idReserva = 0;
                                    string queryMaxId = "SELECT ISNULL(MAX(IdReserva), 0) + 1 FROM Reservas";
                                    using (SqlCommand commandMaxId = new SqlCommand(queryMaxId, connection))
                                    {
                                        idReserva = (int)commandMaxId.ExecuteScalar();
                                    }

                                    // Insertar en tabla Reservas con IdReserva
                                    string queryReserva = "INSERT INTO Reservas (IdReserva, fila, columna, nombreCliente) VALUES (@idReserva, @fila, @columna, @nombreCliente)";
                                    using (SqlCommand commandReserva = new SqlCommand(queryReserva, connection))
                                    {
                                        commandReserva.Parameters.AddWithValue("@idReserva", idReserva);  // IdReserva manual
                                        commandReserva.Parameters.AddWithValue("@fila", fila + 1);  // Convertir a base 1
                                        commandReserva.Parameters.AddWithValue("@columna", columna + 1);
                                        commandReserva.Parameters.AddWithValue("@nombreCliente", nombreCliente);

                                        commandReserva.ExecuteNonQuery();
                                    }

                                    // Actualizar el estado en tabla Asientos a 'Ocupado'
                                    string queryActualizarAsiento = "UPDATE Asientos SET estado = 1 WHERE fila = @fila AND columna = @columna"; // 1 para 'Ocupado'
                                    using (SqlCommand commandAsiento = new SqlCommand(queryActualizarAsiento, connection))
                                    {
                                        commandAsiento.Parameters.AddWithValue("@fila", fila + 1);
                                        commandAsiento.Parameters.AddWithValue("@columna", columna + 1);
                                        commandAsiento.ExecuteNonQuery();
                                    }

                                    // Mostrar el idReserva al usuario
                                    MessageBox.Show($"Asiento reservado en fila {fila + 1}, columna {columna + 1} para {nombreCliente}. ID de Reserva: {idReserva}.");
                                }

                                // Actualizar visualmente el asiento
                                asientos[fila, columna].BackColor = Color.Red;
                                asientos[fila, columna].Tag = "Ocupado"; // Actualiza la etiqueta del bot�n a "Ocupado"
                            }
                            catch (SqlException ex)
                            {
                                MessageBox.Show("Error al realizar la reserva: " + ex.Message);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Debe ingresar un nombre v�lido para hacer la reserva.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Este asiento ya est� reservado.");
                    }
                }
                else
                {
                    MessageBox.Show("Fila o columna fuera de rango.");
                }
            }
            else
            {
                MessageBox.Show("Entrada inv�lida. Aseg�rate de usar el formato correcto.");
            }
        }


        public void CancelarReserva()
        {
            string input = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el ID de Reserva:", "Cancelar Reserva", "1");
            if (int.TryParse(input, out int idReserva))
            {
                string nombreCliente = Microsoft.VisualBasic.Interaction.InputBox("Ingrese su nombre:", "Cancelar Reserva", "Nombre");

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        // Verificar que la reserva existe
                        string queryVerificar = "SELECT fila, columna FROM Reservas WHERE idReserva = @idReserva AND nombreCliente = @nombreCliente";
                        int filaReservada = 0, columnaReservada = 0;

                        using (SqlCommand commandVerificar = new SqlCommand(queryVerificar, connection))
                        {
                            commandVerificar.Parameters.AddWithValue("@idReserva", idReserva);
                            commandVerificar.Parameters.AddWithValue("@nombreCliente", nombreCliente);
                            using (SqlDataReader reader = commandVerificar.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    filaReservada = reader.GetInt32(0);
                                    columnaReservada = reader.GetInt32(1);
                                }
                                else
                                {
                                    MessageBox.Show("No se encontr� la reserva con ese ID y nombre.");
                                    return;
                                }
                            }
                        }

                        // Eliminar la reserva
                        string queryEliminar = "DELETE FROM Reservas WHERE idReserva = @idReserva";
                        using (SqlCommand commandEliminar = new SqlCommand(queryEliminar, connection))
                        {
                            commandEliminar.Parameters.AddWithValue("@idReserva", idReserva);
                            commandEliminar.ExecuteNonQuery();
                        }

                        // Actualizar el estado del asiento a "Disponible"
                        string queryActualizarAsiento = "UPDATE Asientos SET estado = 0 WHERE fila = @fila AND columna = @columna"; // 0 para 'Disponible'
                        using (SqlCommand commandActualizar = new SqlCommand(queryActualizarAsiento, connection))
                        {
                            commandActualizar.Parameters.AddWithValue("@fila", filaReservada);
                            commandActualizar.Parameters.AddWithValue("@columna", columnaReservada);
                            commandActualizar.ExecuteNonQuery();
                        }

                        // Actualizar visualmente el asiento
                        asientos[filaReservada - 1, columnaReservada - 1].BackColor = Color.Green;
                        asientos[filaReservada - 1, columnaReservada - 1].Tag = "Disponible"; // Actualiza la etiqueta del bot�n a "Disponible"

                        MessageBox.Show($"Reserva con ID {idReserva} cancelada exitosamente.");
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error al cancelar la reserva: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("ID de reserva inv�lido.");
            }
        }


        public void MostrarReservas()
        {
            string reservas = "Reservas actuales:\n";
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT IdReserva, fila, columna, nombreCliente FROM Reservas";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                reservas += $"ID: {reader["IdReserva"]}, Fila: {reader["fila"]}, Columna: {reader["columna"]}, Nombre: {reader["nombreCliente"]}\n";
                            }
                        }
                    }
                }
                MessageBox.Show(reservas, "Reservas Actuales");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error al cargar las reservas: " + ex.Message);
            }
        }

        private void CargarReservasDesdeBD()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT fila, columna FROM Reservas";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int fila = reader.GetInt32(0) - 1; // Ajustar a 0-based
                                int columna = reader.GetInt32(1) - 1; // Ajustar a 0-based

                                asientos[fila, columna].BackColor = Color.Red;
                                asientos[fila, columna].Tag = "Ocupado";
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error al cargar reservas al inicio: " + ex.Message);
            }
        }
        public void GuardarAsientosEnBD()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Eliminar los asientos existentes antes de agregar nuevos
                    string queryEliminar = "DELETE FROM Asientos";
                    using (SqlCommand commandEliminar = new SqlCommand(queryEliminar, connection))
                    {
                        commandEliminar.ExecuteNonQuery();
                    }

                    // Insertar asientos
                    for (int fila = 1; fila <= 4; fila++)  // Suponiendo que las filas van de 1 a 4
                    {
                        for (int columna = 1; columna <= 5; columna++)  // Suponiendo que las columnas van de 1 a 5
                        {
                            string queryInsertar = "INSERT INTO Asientos (fila, columna, estado) VALUES (@fila, @columna, @estado)";
                            using (SqlCommand commandInsertar = new SqlCommand(queryInsertar, connection))
                            {
                                commandInsertar.Parameters.AddWithValue("@fila", fila);
                                commandInsertar.Parameters.AddWithValue("@columna", columna);
                                commandInsertar.Parameters.AddWithValue("@estado", 0);  // 0 para "Disponible"

                                commandInsertar.ExecuteNonQuery();
                            }
                        }
                    }
                }
                MessageBox.Show("Asientos guardados en la base de datos.");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error al guardar los asientos: " + ex.Message);
            }
        }

    }
}

